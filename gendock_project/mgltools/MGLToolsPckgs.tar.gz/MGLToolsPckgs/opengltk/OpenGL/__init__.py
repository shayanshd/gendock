#
# copyright_notice
#

"""module ensuring backward compatibility with PyOpenGL
"""

__all__ = ('GL', 'GLU')
