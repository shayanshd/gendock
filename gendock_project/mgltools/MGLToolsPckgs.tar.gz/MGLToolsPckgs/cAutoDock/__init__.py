
__MGLTOOLSVersion__ = '1-4alpha3'
CRITICAL_DEPENDENCIES = ['MolKit', 'PyAutoDock', 'memoryobject']
NONCRITICAL_DEPENDENCIES = []
